﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelManager : MonoBehaviour {
	public float waitToRespawn;
	public PlayerController thePlayer;
	public GameObject deathSplosion;
	public Text coinText;
	public GameObject gameOverScreen;
	public Image heart1;
	public Image heart2;
	public Image heart3;
	public Sprite heartFull;
	public Sprite heartEmpty;
	public int maxHealth;
	public int healthCount;
	private bool respawning;

	public Text livesText;
	public int startingLives;
	public int currentLives;
	// Use this for initialization
	void Start () {
		thePlayer = FindObjectOfType<PlayerController> ();
	
		healthCount = maxHealth;
		currentLives = startingLives;
		livesText.text = "Lives x" + currentLives;
	
	}
	
	// Update is called once per frame
	void Update () {
		if (healthCount <= 0 && !respawning) {
			Respawn ();
			respawning = true;
		}
	}

	public void Respawn(){
		currentLives -= 1;
		livesText.text = "Lives x" + currentLives;
		if (currentLives > 0) {
			StartCoroutine ("RespawnCo");
		}
		else {
			thePlayer.gameObject.SetActive (false);
			gameOverScreen.SetActive (true);
		}
	}
	public IEnumerator RespawnCo(){
		thePlayer.gameObject.SetActive (false);
		Instantiate (deathSplosion, thePlayer.transform.position, thePlayer.transform.rotation);
		yield return new WaitForSeconds (waitToRespawn);			//break the follow of this script, wait for certain amount of time
		healthCount = maxHealth;
		respawning = false;
		UpdateHeartMeter ();

		thePlayer.transform.position = thePlayer.respawnPosition;
		thePlayer.gameObject.SetActive (true);
	}
	public void HurtPlayer(int damageToTake){
		healthCount -= damageToTake; 
		UpdateHeartMeter ();
	}
	public void UpdateHeartMeter(){
		switch (healthCount) {
		case 3:
			heart1.sprite = heartFull;
			heart2.sprite = heartFull;
			heart3.sprite = heartFull;
			return;
		case 2:
			heart1.sprite = heartFull;
			heart2.sprite = heartFull;
			heart3.sprite = heartEmpty;
			return;
		case 1:
			heart1.sprite = heartFull;
			heart2.sprite = heartEmpty;
			heart3.sprite = heartEmpty;
			return;
		case 0:
			heart1.sprite = heartEmpty;
			heart2.sprite = heartEmpty;
			heart3.sprite = heartEmpty;
			return;
		default: 
			heart1.sprite = heartEmpty;
			heart2.sprite = heartEmpty;
			heart3.sprite = heartEmpty;
			return;
		}
	}
}
